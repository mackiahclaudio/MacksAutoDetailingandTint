Mack's Automotive Detail and Tint website — v4

Changes:
- Removed vehicle match and 3D viewer
- Clicking a service adds/removes it from the booking
- Selected service prices immediately flow into the total
- Checkout summary includes all services and the final amount
- Appointment times are offered in 1-hour increments from 8:00 AM through 10:00 PM
- Sedan tint $250
- SUV / Truck tint $300
- Boat cleaning $500
- Motorcycle cleaning $100
- Unlimited Wash Plan $300/month
- Contact information remains at the top of the website

Checkout is currently a front-end demo. Connect Stripe, Square, PayPal, or another payment processor to accept real payments online.
